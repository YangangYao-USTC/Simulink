function [sys,x0,str,ts] = spacemodel(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 1,
    sys=mdlDerivatives(t,x,u);
case 3,
    sys=mdlOutputs(t,x,u);
case {2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 2;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 2;
sizes.NumInputs      = 1;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 1;
sys = simsizes(sizes);
x0  = [0.5;1.5];
str = [];
ts  = [0 0];
function sys=mdlDerivatives(t,x,u)
rho=zeros(size(t));tau=zeros(size(t));d1=zeros(size(t));d2=zeros(size(t));
for i=1:length(t)
if t(i)<10
rho(i)=1;tau(i)=0;d1(i)=0;d2(i)=0;
elseif (t(i)>=10)&&(t(i)<27.6)
rho(i)=0.5+0.1*sin(t(i));tau(i)=0.3*cos(t(i))*exp(3*sin(t(i)));d1(i)=0.001*sin(t(i));d2(i)=0.001*cos(t(i));
elseif  (t(i)>=27.6)&&(t(i)<35.2)
rho(i)=1;tau(i)=0;d1(i)=0;d2(i)=0;
elseif (t(i)>=35.2)&&(t(i)<52.7)
rho(i)=0.5+0.1*sin(t(i));tau(i)=0.3*cos(t(i))*exp(3*sin(t(i)));d1(i)=0.001*sin(t(i));d2(i)=0.001*cos(t(i));
else 
rho(i)=1;tau(i)=0;d1(i)=0;d2(i)=0;
end
end
ut=u(1);
sys(1)=x(2)+sin(x(1)*x(1))*cos(x(1))+d1;
sys(2)=x(1)*sin(x(2))*(1+x(2)*x(2))-1.2*x(1)*x(2)+rho*ut+tau+d2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   Plant (63)
function sys=mdlOutputs(t,x,u)

sys(1)=x(1);
sys(2)=x(2);

