function [sys,x0,str,ts]=s_function(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 1,
    sys=mdlDerivatives(t,x,u);
case 3,
    sys=mdlOutputs(t,x,u);
case {2, 4, 9 }
    sys = [];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
global hidden1 c1 T a1 kappa p1 p2 p a b;
sizes = simsizes;
sizes.NumContStates  =1;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     =6;
sizes.NumInputs      =2;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;
sys=simsizes(sizes);
x0=3;         %%%%%%%%%%%%%%%%%%%% \hat{\Psi}_1(0)=3
str=[];
ts=[-1 0];
hidden1=9;c1=80;T=5;a1=10;kappa=0.00001;b=0.4;
function sys=mdlDerivatives(t,x,u)
global hidden1 a1 c1 T kappa b;
yr=0.5*cos(0.5*t)-0.4*sin(0.25*t)-0.25;
dyr=0.5*cos(0.5*t)+1.5*0.25*cos(0.25*t);
B1=-b+0.01*sin(t);B2=b+0.01*sin(t);
%%%%%%%%%%%%%%%%%%%%  constrained boundary
xi1=u(1);
hxi2=u(2);


S=zeros(size(t));
for i=1:length(t)
if t(i)<10
S(i)=exp(-(t(i)-10).^4/0.0001);
elseif (t(i)>=10)&&(t(i)<27.6)
S(i)=1;
elseif  (t(i)>=27.6)&&(t(i)<35.2)
S(i)=exp(((-4.*(2.*t(i)-27.6-35.2).^5.*sign(2.*t(i)-27.6-35.2))./(7.6).^5+(5.*(2.*t(i)-27.6-35.2).^4)./(7.6).^4-1)/0.0001);
elseif (t(i)>=35.2)&&(t(i)<52.7)
S(i)=1;
else 
    S(i)=exp(-((52.7-t(i)).^4)/0.0001);
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% stretching function (23)
e1=xi1-yr;
zeta1=e1*S;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% auxiliary variable (24)
if (B1<zeta1)&(zeta1<=0)
    N1=1;    
else (0<zeta1)&(zeta1<B2)
    N1=0;
end
h1=-N1*(zeta1/B1)^4+1;
h2=-(1-N1)*(zeta1/B2)^4+1;

eta1=e1/(h1*h2); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  stretch model-based NMF (25)
epc=0.01;

xxx=[xi1;hxi2;eta1;dyr;yr];

d1=0.5*[-4 -3.5 -3 -2.5 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2 2.5 3 3.5 4;
    -4 -3.5 -3 -2.5 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2 2.5 3 3.5 4;
    -4 -3.5 -3 -2.5 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2 2.5 3 3.5 4;
    -4 -3.5 -3 -2.5 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2 2.5 3 3.5 4;
    -4 -3.5 -3 -2.5 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2 2.5 3 3.5 4];

for i=1:hidden1
    kexi1(i)=exp(-((norm(xxx-0.5*d1(:,i)))^2));
end
fai1=kexi1';
if t<=T
    u=1/(kappa+(1-kappa).*(1-t/T)^3);dF=((3/T).*(1-kappa).*(1-t/T)^2)/(kappa+(1-kappa).*(1-t/T)^3)^2;
else
    u=1/kappa;dF=0;
end
barS1=c1+dF/u;
rl=50;
b11=N1/B1^4+(1-N1)/B2;
Gamma1=(h1*h2+4*(zeta1^4)*b11)/(h1*h2)^2;
sys=(rl*(Gamma1^2)*(eta1^2)*((norm(fai1,2))^2))/(2*a1*(barS1^4))-barS1*x;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  \hat{Psi}_1 




function sys=mdlOutputs(t,x,u)
global hidden1 a1 c1 T kappa b;
yr=0.5*cos(0.5*t)-0.4*sin(0.25*t)-0.25;
dyr=0.5*cos(0.5*t)+1.5*0.25*cos(0.25*t);

F1=-b+0.01*sin(t);
F2=b+0.01*sin(t);

xi1=u(1);
hxi2=u(2);



S=zeros(size(t));
for i=1:length(t)
if t(i)<10
S(i)=exp(-(t(i)-10).^4/0.0001);
elseif (t(i)>=10)&&(t(i)<27.6)
S(i)=1;
elseif  (t(i)>=27.6)&&(t(i)<35.2)
S(i)=exp(((-4.*(2.*t(i)-27.6-35.2).^5.*sign(2.*t(i)-27.6-35.2))./(7.6).^5+(5.*(2.*t(i)-27.6-35.2).^4)./(7.6).^4-1)/0.0001);
elseif (t(i)>=35.2)&&(t(i)<52.7)
S(i)=1;
else 
    S(i)=exp(-((52.7-t(i)).^4)/0.0001);
end
end

e1=xi1-yr;
zeta1=e1*S;
if (F1<zeta1)&(zeta1<=0)
    N1=1;    
else (0<zeta1)&(zeta1<F2)
    N1=0;
end
h1=-N1*(zeta1/F1)^4+1;
h2=-(1-N1)*(zeta1/F2)^4+1;

eta1=e1/(h1*h2); 

epc=0.01;

xxx=[xi1;hxi2;eta1;dyr;yr];

d1=0.5*[-4 -3.5 -3 -2.5 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2 2.5 3 3.5 4;
    -4 -3.5 -3 -2.5 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2 2.5 3 3.5 4;
    -4 -3.5 -3 -2.5 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2 2.5 3 3.5 4;
    -4 -3.5 -3 -2.5 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2 2.5 3 3.5 4;
    -4 -3.5 -3 -2.5 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2 2.5 3 3.5 4];


for i=1:hidden1
    kexi1(i)=exp(-((norm(xxx-0.5*d1(:,i)))^2));
end
fai1=kexi1';
Psi1=x;
if t<=T
    F=1/(kappa+(1-kappa).*(1-t/T)^3);dF=((3/T).*(1-kappa).*(1-t/T)^2)/(kappa+(1-kappa).*(1-t/T)^3)^2;
else
    F=1/kappa;dF=0;
end
barS1=c1+dF/F;
b11=N1/F1^4+(1-N1)/F2;
kappa1=(h1*h2+4*(zeta1^4)*b11)/(h1*h2)^2;
x2_bar=-(barS1*eta1)/kappa1-(kappa1*eta1*Psi1*(norm(fai1,2))^2)/(2*a1*(barS1^2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  \alpha1 

sys(1)=x2_bar;   
sys(2)=Psi1;
sys(3)=F1;
sys(4)=F2;
sys(5)=yr;
sys(6)=S;


