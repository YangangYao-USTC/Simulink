function [sys,x0,str,ts]=s_function(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 1,
    sys=mdlDerivatives(t,x,u);
case 3,
    sys=mdlOutputs(t,x,u);
case {2, 4, 9 }
    sys = [];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
global hidden2 c2 T a2 kappa;
sizes = simsizes;
sizes.NumContStates  = 1;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 3;
sizes.NumInputs      =3;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;
sys=simsizes(sizes);
x0=2;
str=[];
ts=[-1 0];
hidden2=9;c2=3;T=5;a2=100;kappa=0.00001;
function sys=mdlDerivatives(t,x,u)
global hidden2 c2 T a2 kappa;
xi1=u(1);
hxi2=u(2);
alpha1=u(3);
yr=0.5*cos(t)-0.4*sin(0.5*t)-0.25;

z2=hxi2-alpha1;
epc=0.01;
xx=[xi1;hxi2;z2;alpha1;yr];
hidden2=9;
d2=0.5*[-4 -3.5 -3 -2.5 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2 2.5 3 3.5 4;
    -4 -3.5 -3 -2.5 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2 2.5 3 3.5 4;
    -4 -3.5 -3 -2.5 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2 2.5 3 3.5 4;
    -4 -3.5 -3 -2.5 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2 2.5 3 3.5 4;
    -4 -3.5 -3 -2.5 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2 2.5 3 3.5 4];

b2=1;
for i=1:hidden2
    kesi2(i)=exp(-((norm(xx-d2(:,i)))^2)/(b2^2));
end
fai2=kesi2';
if t<=T
    F=1/(kappa+(1-kappa).*(1-t/T)^3);dF=((3/T).*(1-kappa).*(1-t/T)^2)/(kappa+(1-kappa).*(1-t/T)^3)^2;
else
    F=1/kappa;dF=0;
end
barS2=c2+dF/F;
r2=150;
sys=(r2*(z2^2)*(norm(fai2,2))^2)/(2*a2*(barS2^4))-barS2*x;




function sys=mdlOutputs(t,x,u)
global hidden2 c2 T kappa a2;
xi1=u(1);
hxi2=u(2);
alpha1=u(3);
yr=0.5*cos(t)-0.4*sin(0.5*t)-0.25;
z2=hxi2-alpha1;


epc=0.01;




xx=[xi1;hxi2;z2;alpha1;yr];

d2=0.5*[-4 -3.5 -3 -2.5 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2 2.5 3 3.5 4;
    -4 -3.5 -3 -2.5 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2 2.5 3 3.5 4;
    -4 -3.5 -3 -2.5 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2 2.5 3 3.5 4;
    -4 -3.5 -3 -2.5 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2 2.5 3 3.5 4;
    -4 -3.5 -3 -2.5 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2 2.5 3 3.5 4];

b2=1;
for i=1:hidden2
    kesi2(i)=exp(-((norm(xx-d2(:,i)))^2)/(b2^2));
end
fai2=kesi2';
Psi2=x;
if t<=T
    F=1/(kappa+(1-kappa).*(1-t/T)^3);dF=((3/T).*(1-kappa).*(1-t/T)^2)/(kappa+(1-kappa).*(1-t/T)^3)^2;
else
    F=1/kappa;dF=0;
end
barS2=c2+dF/F;
ut=-(barS2*z2)-(z2*Psi2*(norm(fai2,2))^2)/(2*a2*(barS2^2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  u(t) 
rho=zeros(size(t));tau=zeros(size(t));
for i=1:length(t)
if t(i)<10
rho(i)=1;tau(i)=0;
elseif (t(i)>=10)&&(t(i)<27.6)
rho(i)=0.5+0.1*sin(t(i));tau(i)=0.3*cos(t(i))*exp(3*sin(t(i)));
elseif  (t(i)>=27.6)&&(t(i)<35.2)
rho(i)=1;tau(i)=0;
elseif (t(i)>=35.2)&&(t(i)<52.7)
rho(i)=0.5+0.1*sin(t(i));tau(i)=0.3*cos(t(i))*exp(3*sin(t(i)));
else 
rho(i)=1;tau(i)=0;
end
end
ut1=rho*ut+tau;


sys(1)=ut; 
sys(2)=Psi2; 
sys(3)=ut1;
