function [sys,x0,str,ts] = spacemodel(t,x,u,flag)
switch flag
    case 0
    [sys,x0,str,ts]=mdlInitializeSizes;
    case 1
    sys=mdlDerivatives(t,x,u);
    case 3
    sys=mdlOutputs(t,x,u);
case {2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 2;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 2;
sizes.NumInputs      = 2;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 1;
sys = simsizes(sizes);
x0  = [0.1;1.5];
str = [];
ts  = [0 0];

function sys=mdlDerivatives(t,x,u)
T=4;kappa=0.0001;
if t<T
    F=1/(kappa+(1-t/T)^3);dF=((3/T)*(1-t/T)^2)/(kappa+(1-t/T)^3)^2;
else
    F=1/kappa;dF=0;
end
C0=38+dF/F;
x1=u(1);ut=u(2);
sys(1)=x(2)+C0*(x1-x(1));
sys(2)=ut+C0^2*(x1-x(1));


function sys=mdlOutputs(t,x,u)
sys(1)=x(1);
sys(2)=x(2);
